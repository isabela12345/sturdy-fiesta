The Notes App
I am going to create a simple Notes App with SQLite as database storage. 
The app will be very minimal and will have only one screen to manage the notes.

I've learned basics of SQLite database with a realtime example of Notes App :
 
->Inserting Note : Inserting data requires getting writable instance (getReadableDatabase()) on database. 
     1. ContentValues() is used to define the column name and its data to be stored. Here, we are just setting the note value only ignoring `id` and `timestamp` as these two will be inserted automatically.
     2. Every time the database connection has to be closed once you are done with database access. Calling db.close() closes the connection.
     3. Once the note is inserted, the `id` of newly inserted note will be returned.

->Reading Notes : Reading data requires only read access (getReadableDatabase()) on the database.
     1. getNote() takes already existed note `id` and fetches the note object.
     2. getAllNotes() fetches all the notes in descending order by timestamp.
     3. getNotesCount() returns the count of notes stored in database.

->Updating Note : Updating data again requires writable access.

->Deleting Note : Deleting data also requires writable access.


									Mazilu Isabela- Elena
									1240F


